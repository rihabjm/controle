import { Component, OnInit } from '@angular/core';
import { MembreService } from '../../Service/membre.service';
import { Membre } from '../../Model/membre';
import { FormGroup, FormControl } from '@angular/forms';
@Component({
  selector: 'app-membre-delete',
  templateUrl: './membre-delete.component.html',
  styleUrls: ['./membre-delete.component.css']
})
export class MembreDeleteComponent implements OnInit {
 m: Membre[] = new Array();
membre : Membre ;
  constructor(private membreservice: MembreService ) { }

  ngOnInit() {this.getAll();}


 private getAll() {

  this.membreservice.getAll().subscribe(data => {

     this.m= data ;
      console.log(data);
    }, ex => {
      console.log(ex);
    });
}


  private update(membre : Membre) {
    this.membreservice.update(membre).subscribe( data => {

     if (data.success) { this.getAll();} else {}
    }, ex => {console.log(ex);
    });
  }

}






















