export class Membre {
cin : number ;
nom : String ;
prenom : String ;
tel : number  ;
adresse :String ;
poste_membre :String ;
email:String;
login : String ;
typeagent :String ;
}
