import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RensignementComponent } from './rensignement/rensignement.component';
import { RensignementAddComponent } from './rensignement-add/rensignement-add.component';
import { RensignementUpdateComponent } from './rensignement-update/rensignement-update.component';
 import {  RensignementDeleteComponent } from './rensignement-delete/rensignement-delete.component';

import { RensignementListComponent } from './rensignement-list/rensignement-list.component';
import { RensignementValideComponent } from './rensignement-valide/rensignement-valide.component';
const routes: Routes = [
{
        path: 'reunion',
        component: RensignementComponent,
        children: [
            {
                path: 'add',
                component: RensignementAddComponent
            },
   {
                path: 'update',
                component: RensignementUpdateComponent
            }

  ,
   {
                path: 'delete',
                component:  RensignementDeleteComponent
            }
 ,
   {
                path: 'valide',
                component:  RensignementValideComponent
            }
 ,
   {
                path: 'list',
                component:  RensignementListComponent
            }

        ]
    }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RensignementRoutingModule { }
