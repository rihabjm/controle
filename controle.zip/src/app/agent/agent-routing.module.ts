import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AgentDroitComponent } from './agent-droit/agent-droit.component';
import { AgentListComponent } from './agent-list/agent-list.component';
import { AgentComponent } from './agent/agent.component';
const routes: Routes = [
{path: 'agent',
        component: AgentComponent ,
        children: [
            {
                path: 'list',
                component: AgentListComponent
            },
            {
                path: 'droit',
                component: AgentDroitComponent
            },
]

}

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AgentRoutingModule { }
