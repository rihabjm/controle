import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TemplateComponent } from './templates/template/template.component';
import {HTTP_INTERCEPTORS, HttpClientModule ,HttpParams ,HttpHeaders,HttpErrorResponse} from '@angular/common/http';
import { RensignementModule } from './rensignement/rensignement.module';
import { MembreModule } from './membre/membre.module';
import { FormsModule, ReactiveFormsModule  } from '@angular/forms';
 import {AgentModule }from './agent/agent.module';
import { MenuComponent } from './menu/menu.component';



@NgModule({
  declarations: [
    AppComponent,
    TemplateComponent,
    MenuComponent,

 ],
  imports: [
    BrowserModule,
    AppRoutingModule ,
    RensignementModule,
    MembreModule,
    HttpClientModule,
  FormsModule
,ReactiveFormsModule ,
AgentModule ,

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
