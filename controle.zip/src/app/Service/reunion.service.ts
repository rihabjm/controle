import { Injectable } from '@angular/core';
import {Reunion} from '../model/reunion' ;
import {Config} from '../utils/Config';
import {HttpClient ,HttpParams} from '@angular/common/http';
import {Observable} from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class ReunionService {
  private url = Config.BASE_URL + '/reunion';

  constructor(private httpClient:HttpClient) { }

    public delete(id): Observable<any> {
    return this.httpClient.delete(this.url + '/' + id);
  }

   public getAll(): Observable<Reunion[]> {
    return this.httpClient.get<Reunion[]>(this.url);
  }
   public chercher(obj): Observable<Reunion[]> {
    return this.httpClient.get<Reunion[]>(this.url+'/byobj/'+obj);
  }


 public update(reunion:Reunion ): Observable<any> {

  return this.httpClient.post(this.url+'/up' , reunion);
  }

 public save(reunion: Reunion): Observable<any> {

  return this.httpClient.post(this.url+'/add', reunion);
  }

public valide(reunion: Reunion ): Observable<any> {

  return this.httpClient.put(this.url+'/valide' , reunion);
  }

}

